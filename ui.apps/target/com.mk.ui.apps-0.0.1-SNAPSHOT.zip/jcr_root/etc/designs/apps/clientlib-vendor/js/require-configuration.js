
(function (){
    'use strict';

    define(
        'jquery',
        [],
        function() {
            return jQuery;
    });

}());